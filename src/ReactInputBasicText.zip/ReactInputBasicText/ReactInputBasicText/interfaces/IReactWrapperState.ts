export default interface IReactWrapperState {
    value: string
}