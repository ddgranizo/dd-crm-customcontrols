export default interface IReactWrapperProps{
    value: string,
    handlerChange: Function
}